﻿using UnityEngine;
using System.Collections;

public class MU_pcmovement : MonoBehaviour
{
    public float movespeed;
    private Rigidbody2D rigidbody;
    public float fallingspeed;
    private float campos;
    private Vector3 cameraposition;
    // Use this for initialization
    void Start()
    {
        cameraposition = Camera.main.transform.position;
        campos = Camera.main.transform.position.x;
        rigidbody=GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        rigidbody.velocity = new Vector3(0,-fallingspeed);
        move();
    }
    void LateUpdate()
    {
        Camera.main.transform.position = new Vector3(campos, Camera.main.transform.position.y, Camera.main.transform.position.z);
    }
    void move()
    {
        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            this.gameObject.transform.Translate(Vector3.right * movespeed);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            this.gameObject.transform.Translate(Vector3.left * movespeed);
        }
    }
   
    void  OnCollisionEnter2D(Collision2D coll)
    {
        if(coll.gameObject.tag=="officer")
        {
            //Camera.main.transform.parent = null;
            Destroy(this.gameObject, 0.1f);
        }
        //if(coll.gameObject.tag=="endfloor1")
        //{

        //}
    }
}
